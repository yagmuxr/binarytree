#include <iostream>
#include <string>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include<locale.h>
#include <istream>
//node yap�s�n� tan�mla
struct node
{
  int data;
  struct node* rlink;
  struct node* llink;	
};
//programda kullan�lacak a�a�lar� tan�mla
node* newnode()
{
	node* newnode= new node;
	newnode->llink=NULL;
	newnode->rlink=NULL;
	std::cin>>newnode->data;
	return(newnode);
}
//tree a�ac�na g�re node_ nodeunu ekle
void inserttree(node*& tree, node* node_)
{
	if(tree==NULL)
	{
		tree=node_;
		return;
	}

    if(node_->data < tree->data)
    inserttree(tree->llink, node_);
    else
    inserttree(tree->rlink, node_);
}
//tree soldan sa�a tara, ekrana listele
void printtree(node* tree)
{
	int i=0;
	if(tree->llink!=NULL)
	printtree(tree->llink);
	
	std::cout<<tree->data<<"\n";
	std::cout<<i++<<". node.\n";
	
	
	if(tree->rlink!=NULL)
	printtree(tree->rlink);
	
}
int main()
{
	node* root=NULL;
	for(int i=1 ; i<=5 ; i++)
	inserttree(root, newnode());
	std::cout<<"--------------------\n";
	
	printtree(root);

}
