void getnodecount(node* tree)
{
	i=0;
	if(tree->llink!=NULL)
	printtree(tree->llink);
	
	cout<<tree->data<<endl;
	i++;
	
	if(tree->rlink!=NULL)
	printtree(tree->rlink);
	
	cout<<i<<". node."<< endl;
		
}
int getLeafCount(node* node)
{
    if(node == NULL)    
        return 0;
    if(node->llink == NULL && node->rlink == NULL)
        return 1;        
    else
        return getLeafCount(node->left)+
            getLeafCount(node->right);
}

